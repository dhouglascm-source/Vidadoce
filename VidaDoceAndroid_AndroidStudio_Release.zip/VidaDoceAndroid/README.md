# VidaDoce — Projeto Android Studio

Projeto Android Studio do aplicativo **VidaDoce**, com duas telas principais:

- Registrar Glicemia
- Histórico e Gráfico

## Abrir no Android Studio

1. Extraia o ZIP.
2. Abra a pasta `VidaDoceAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale o Android SDK 35 e use o JDK 11 ou compatível com o Android Gradle Plugin.

## Gerar APK de teste

No menu do Android Studio:

`Build > Build APK(s)`

O APK de debug ficará em:

`app/build/outputs/apk/debug/`

## Gerar APK de lançamento

Use:

`Build > Generate Signed Bundle / APK > APK > release`

Na primeira vez, crie ou selecione um keystore próprio. **Não compartilhe o arquivo do keystore nem suas senhas.**

O APK de release será gerado em:

`app/build/outputs/apk/release/`

## Identidade do aplicativo

- Nome: VidaDoce
- Application ID: `com.vidadoce.app`
- Versão: `1.2.0`
- Ícone: coração com gota e folha, em tons vinho, rosa, verde-sálvia e creme.

## Observação

O aplicativo é destinado ao registro e organização de medições. Ele não diagnostica condições médicas nem altera doses de medicamentos ou insulina.
