# VidaDoce release rules.
# The app uses a local WebView bundle; no custom shrinking rules are required.
